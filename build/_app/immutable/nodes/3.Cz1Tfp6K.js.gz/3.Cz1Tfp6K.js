import{t,a as e}from"../chunks/CvjfFTcJ.js";var p=t("<h1>Home</h1>");function m(a){var o=p();e(a,o)}export{m as component};
