import{F as o,G as p,o as f,I as i,J as c,p as d,d as h}from"./CbVtA98w.js";function l(e,n,...t){var s=e,r=i,a;o(()=>{r!==(r=n())&&(a&&(c(a),a=null),a=f(()=>r(s,...t)))},p),d&&(s=h)}export{l as s};
