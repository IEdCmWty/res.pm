import{a as t}from"../chunks/B9Ck96Kx.js";export{t as start};
