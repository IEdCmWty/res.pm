import{a as t}from"../chunks/BHeX9DS6.js";export{t as start};
