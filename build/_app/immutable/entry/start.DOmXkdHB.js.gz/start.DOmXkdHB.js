import{l as o,a as r}from"../chunks/w1HHkqjq.js";export{o as load_css,r as start};
