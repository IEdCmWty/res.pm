import{l as o,a as r}from"../chunks/BY8Q34Qx.js";export{o as load_css,r as start};
