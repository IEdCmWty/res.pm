import{a as t}from"../chunks/1lIcTHlC.js";export{t as start};
