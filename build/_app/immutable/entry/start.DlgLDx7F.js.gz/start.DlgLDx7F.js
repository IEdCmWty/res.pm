import{l as o,a as r}from"../chunks/D0uDhDa9.js";export{o as load_css,r as start};
