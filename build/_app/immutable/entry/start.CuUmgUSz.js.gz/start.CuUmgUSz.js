import{a as t}from"../chunks/I2lRbwVo.js";export{t as start};
