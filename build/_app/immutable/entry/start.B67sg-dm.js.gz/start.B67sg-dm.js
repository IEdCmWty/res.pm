import{l as o,a as r}from"../chunks/CkEW812R.js";export{o as load_css,r as start};
