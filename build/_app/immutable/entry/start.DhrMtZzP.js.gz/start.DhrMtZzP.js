import{a as t}from"../chunks/bTsf50lD.js";export{t as start};
